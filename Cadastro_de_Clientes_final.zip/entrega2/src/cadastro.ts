// ===================== 1. Mapeamento dos elementos do HTML (DOM) =====================
const formCadastro = document.querySelector('#client-form') as HTMLFormElement;
const clientIdInput = document.querySelector('#client-id') as HTMLInputElement;
const nomeInput = document.querySelector('#nome') as HTMLInputElement;
const cpfInput = document.querySelector('#cpf') as HTMLInputElement;
const emailInput = document.querySelector('#email') as HTMLInputElement;
const cepInput = document.querySelector('#cep') as HTMLInputElement;
const cidadeInput = document.querySelector('#cidade') as HTMLInputElement;
const estadoInput = document.querySelector('#estado') as HTMLInputElement;
const ruaInput = document.querySelector('#rua') as HTMLInputElement;
const bairroInput = document.querySelector('#bairro') as HTMLInputElement;

const btnSalvar = document.querySelector('#bnt-save') as HTMLButtonElement;
const btnCancelar = document.querySelector('#bnt-cancel') as HTMLButtonElement;
const resultCadastro = document.querySelector('#resultado-cadastro') as HTMLDivElement;

// ===================== 2. Classe Cliente (variáveis tipadas) =====================
class Cliente {
    id: string;
    nome: string;
    cpf: string;
    email: string;
    cep: string;
    cidade: string;
    estado: string;
    rua: string;
    bairro: string;

    constructor(
        id: string,
        nome: string,
        cpf: string,
        email: string,
        cep: string,
        cidade: string,
        estado: string,
        rua: string,
        bairro: string
    ) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
        this.cep = cep;
        this.cidade = cidade;
        this.estado = estado;
        this.rua = rua;
        this.bairro = bairro;
    }
}

// ===================== 3. Array em memória (armazena a lista de clientes) =====================
let listaClientes: Cliente[] = [];

// ===================== 4. Listar registros: desenha os cards na tela =====================
function renderizarLista(): void {
    resultCadastro.innerHTML = '';

    // Estrutura de repetição: percorre o array de clientes
    listaClientes.forEach((cliente, index) => {
        const itemHtml = `
            <div class="cliente-item">
                <div class="cliente-info">
                    <h3>Cliente #${index + 1}: ${cliente.nome}</h3>
                    <p><strong>CPF:</strong> ${cliente.cpf} | <strong>Email:</strong> ${cliente.email}</p>
                    <p><strong>Endereço:</strong> ${cliente.rua}${cliente.bairro ? ', ' + cliente.bairro : ''} - ${cliente.cidade}/${cliente.estado} - CEP: ${cliente.cep}</p>
                </div>
                <div>
                    <button class="bnt bnt-secondary btn-editar" data-id="${cliente.id}">Alterar Dados</button>
                    <button class="bnt bnt-secondary btn-excluir" data-id="${cliente.id}">Excluir</button>
                </div>
            </div>
        `;
        resultCadastro.innerHTML += itemHtml;
    });

    // Vincula clique de cada botão "Alterar Dados"
    const botoesEditar = document.querySelectorAll('.btn-editar');
    botoesEditar.forEach((botao) => {
        botao.addEventListener('click', (e: Event) => {
            const target = e.currentTarget as HTMLButtonElement;
            const id = target.getAttribute('data-id');
            if (id) {
                carregarDadosParaEdicao(id);
            }
        });
    });

    // Vincula clique de cada botão "Excluir"
    const botoesExcluir = document.querySelectorAll('.btn-excluir');
    botoesExcluir.forEach((botao) => {
        botao.addEventListener('click', (e: Event) => {
            const target = e.currentTarget as HTMLButtonElement;
            const id = target.getAttribute('data-id');
            if (id) {
                excluirCliente(id);
            }
        });
    });
}

// ===================== 5. Editar registros: puxa os dados de volta pro formulário =====================
function carregarDadosParaEdicao(id: string): void {
    const clienteEncontrado = listaClientes.find((c) => c.id === id);

    // Estrutura de decisão
    if (clienteEncontrado) {
        clientIdInput.value = clienteEncontrado.id;
        nomeInput.value = clienteEncontrado.nome;
        cpfInput.value = clienteEncontrado.cpf;
        emailInput.value = clienteEncontrado.email;
        cepInput.value = clienteEncontrado.cep;
        cidadeInput.value = clienteEncontrado.cidade;
        estadoInput.value = clienteEncontrado.estado;
        ruaInput.value = clienteEncontrado.rua;
        bairroInput.value = clienteEncontrado.bairro;

        // Modo de edição: o mesmo botão "Salvar" passa a atualizar
        btnSalvar.textContent = 'Atualizar Cadastro';
        btnCancelar.style.display = 'inline-block';

        formCadastro.scrollIntoView({ behavior: 'smooth' });
    }
}

// ===================== 6. Excluir registros =====================
function excluirCliente(id: string): void {
    // Estrutura de decisão: confirma antes de excluir
    const confirmar = confirm('Tem certeza que deseja excluir este cliente?');

    if (confirmar) {
        listaClientes = listaClientes.filter((c) => c.id !== id);
        renderizarLista();
    }
}

// ===================== 7. Resetar formulário =====================
function resetarFormulario(): void {
    formCadastro.reset();
    clientIdInput.value = '';
    btnSalvar.textContent = 'Salvar Cadastro';
    btnCancelar.style.display = 'none';
}

// ===================== 8. Evento principal: Cadastrar ou Atualizar =====================
formCadastro.addEventListener('submit', (event: Event) => {
    event.preventDefault();

    const idExistente = clientIdInput.value;

    // Estrutura de decisão: já existe ID? então é atualização, senão é um novo cadastro
    if (idExistente) {
        const clienteIndex = listaClientes.findIndex((c) => c.id === idExistente);
        if (clienteIndex !== -1) {
            listaClientes[clienteIndex] = new Cliente(
                idExistente,
                nomeInput.value,
                cpfInput.value,
                emailInput.value,
                cepInput.value,
                cidadeInput.value,
                estadoInput.value,
                ruaInput.value,
                bairroInput.value
            );
        }
    } else {
        const novoCliente = new Cliente(
            Date.now().toString(),
            nomeInput.value,
            cpfInput.value,
            emailInput.value,
            cepInput.value,
            cidadeInput.value,
            estadoInput.value,
            ruaInput.value,
            bairroInput.value
        );
        listaClientes.push(novoCliente);
    }

    renderizarLista();
    resetarFormulario();
});

// ===================== 9. Evento do botão Cancelar =====================
btnCancelar.addEventListener('click', resetarFormulario);
